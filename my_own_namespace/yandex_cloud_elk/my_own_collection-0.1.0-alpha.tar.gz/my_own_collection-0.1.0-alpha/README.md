# Домашнее задание к занятию "6.Создание собственных модулей"

Выполнила Куликова Алёна Владимировна

Для задания были созданы следующее:

- Ansible Collection (смотреть my_own_namespace/yandex_cloud_elk)
- playbook (смотреть my_own_namespace/yandex_cloud_elk/playbook.yml)
- роль для самописного модуля (смотреть my_own_namespace/yandex_cloud_elk/roles/create_file)
- самописный модуль для создания файла (смотреть my_own_namespace/yandex_cloud_elk/roles/create_file)

# Информация об авторе

Задание было выполнено Куликовой Аленой специально для Онлайн обучение на образовательной платформе Нетология.

Если у вас есть вопросы или предложения по улучшению, не стесняйтесь обращаться!

Ссылка на git: https://github.com/Kulikova-A18
